declare module 'ant-design-vue/es/locale/zh_CN';

declare module 'globby!/@/router/routes/modules/**/*.@(ts)';

declare module 'globby!/@/router/menus/modules/**/*.@(ts)';

declare module 'globby?locale!/@/locales/lang/**/*.@(ts)';

declare const React: string;
