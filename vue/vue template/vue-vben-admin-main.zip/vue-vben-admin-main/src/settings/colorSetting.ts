// header preset color
export const HEADER_PRESET_BG_COLOR_LIST: string[] = [
  '#ffffff',
  '#009688',
  '#18bc9c',
  '#1E9FFF',
  '#018ffb',
  '#409eff',
  '#4e73df',
  '#e74c3c',
  '#24292e',
  '#394664',
  '#001529',
];

// sider preset color
export const SIDE_BAR_BG_COLOR_LIST: string[] = [
  '#273352',
  '#ffffff',
  '#191a23',
  '#001529',
  '#304156',
  '#28333E',
  '#344058',
];
