/**
 * copy from element-ui
 */

export { default as Scrollbar } from './src/Scrollbar';
