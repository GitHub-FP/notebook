import StrengthMeterLib from './src/index';
import { withInstall } from '../util';

export const StrengthMeter = withInstall(StrengthMeterLib);
