export { default as QrCode } from './src/index.vue';
export * from './src/types';
