import PageFooterLib from './src/PageFooter.vue';
import { withInstall } from '../util';

export const PageFooter = withInstall(PageFooterLib);
