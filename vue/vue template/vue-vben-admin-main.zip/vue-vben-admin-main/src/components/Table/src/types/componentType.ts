export type ComponentType =
  | 'Input'
  | 'InputPassword'
  | 'InputNumber'
  | 'Select'
  | 'Checkbox'
  | 'CheckboxGroup'
  | 'Switch';
