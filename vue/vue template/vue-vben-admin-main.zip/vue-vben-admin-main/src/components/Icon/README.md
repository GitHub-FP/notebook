### `Icon.vue`

```html
<Icon icon="mdi:account" />
```

The icon id follows the rules in [Iconify](https://iconify.design/) which you can use any icons from the supported icon sets.
