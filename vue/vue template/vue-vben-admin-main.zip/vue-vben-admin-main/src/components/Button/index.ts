import ButtonLib from './src/BasicButton.vue';
import { withInstall } from '../util';

export const Button = withInstall(ButtonLib);
