export { createImgPreview } from './src/functional';
