import { defineComponent } from 'vue';

export type Component = ReturnType<typeof defineComponent>;
