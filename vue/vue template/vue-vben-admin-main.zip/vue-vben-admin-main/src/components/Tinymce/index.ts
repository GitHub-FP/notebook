import TinymceLib from './src/Editor.vue';
import { withInstall } from '../util';

export const Tinymce = withInstall(TinymceLib);
