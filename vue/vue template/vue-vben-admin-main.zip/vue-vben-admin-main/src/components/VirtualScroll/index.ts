import VirtualScrollLib from './src/index';
import { withInstall } from '../util';

export const VirtualScroll = withInstall(VirtualScrollLib);
