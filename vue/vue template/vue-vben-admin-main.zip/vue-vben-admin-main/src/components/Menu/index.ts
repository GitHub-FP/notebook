import BasicMenuLib from './src/BasicMenu';
import { withInstall } from '../util';

export const BasicMenu = withInstall(BasicMenuLib);
