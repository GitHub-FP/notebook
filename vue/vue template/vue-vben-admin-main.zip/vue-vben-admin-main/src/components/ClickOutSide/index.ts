import ClickOutSideLib from './src/index.vue';
import { withInstall } from '../util';

export const ClickOutSide = withInstall(ClickOutSideLib);
