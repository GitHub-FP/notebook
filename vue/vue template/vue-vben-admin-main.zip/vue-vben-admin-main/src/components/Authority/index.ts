import AuthorityLib from './src/index.vue';

import { withInstall } from '../util';

export const Authority = withInstall(AuthorityLib);
