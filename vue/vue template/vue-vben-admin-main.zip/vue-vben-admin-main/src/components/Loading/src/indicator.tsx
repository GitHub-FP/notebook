// If you need to modify the default icon, you can open the comment and modify it here

// import { Spin } from 'ant-design-vue';
// import { LoadingOutlined } from '@ant-design/icons-vue';
// Spin.setDefaultIndicator({
//   indicator: () => {
//     return <LoadingOutlined spin />;
//   },
// });
