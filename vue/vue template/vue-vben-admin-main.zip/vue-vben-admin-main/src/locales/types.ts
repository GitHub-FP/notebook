export type LocaleType = 'zh_CN' | 'en' | 'ru' | 'ja';
