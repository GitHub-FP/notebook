export default {
  loadingText: 'Loading...',
  cancelText: 'Close',
  okText: 'Confirm',
};
