export default {
  // user dropdown
  dropdownItemDoc: 'Document',
  dropdownItemLoginOut: 'Login Out',

  tooltipErrorLog: 'Error log',
  tooltipLock: 'Lock screen',
  tooltipNotify: 'Notification',
  tooltipRedo: 'Refresh',
  tooltipEntryFull: 'Full Screen',
  tooltipExitFull: 'Exit Full Screen',

  // lock
  lockScreenPassword: 'Lock screen password',
  lockScreen: 'Lock screen',
  lockScreenBtn: 'Locking',
  notLockScreenPassword: 'No password lock screen',

  home: 'Home',
};
