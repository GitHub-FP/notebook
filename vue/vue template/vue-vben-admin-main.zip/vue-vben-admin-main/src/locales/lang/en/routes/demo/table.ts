export default {
  table: 'Table',

  basic: 'Basic',
  treeTable: 'Tree',
  fetchTable: 'Remote loading',
  fixedColumn: 'Fixed column',
  customerCell: 'Custom column',
  formTable: 'Open search',
  useTable: 'UseTable',
  refTable: 'RefTable',
  multipleHeader: 'MultiLevel header',
  mergeHeader: 'Merge cells',
  expandTable: 'Expandable table',
  fixedHeight: 'Fixed height',
  footerTable: 'Footer',
  editCellTable: 'Editable cell',
  editRowTable: 'Editable row',
};
