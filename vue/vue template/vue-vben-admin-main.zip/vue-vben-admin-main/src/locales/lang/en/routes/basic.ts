export default {
  login: 'Login',
};
