export default {
  loginOutTip: 'Reminder',
  loginOutMessage: 'Confirm to exit the system?',
  menuLoading: 'Menu loading...',
};
