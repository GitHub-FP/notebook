export default {
  excel: 'Excel',
  customExport: 'Select export format',
  jsonExport: 'JSON data export',
  arrayExport: 'Array data export',
  importExcel: 'Import',
};
