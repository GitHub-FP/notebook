export default {
  alert: 'Lock screen password error',
  backToLogin: 'Back to login',
  entry: 'Enter the system',
  placeholder: 'Please enter the lock screen password or user password',
};
