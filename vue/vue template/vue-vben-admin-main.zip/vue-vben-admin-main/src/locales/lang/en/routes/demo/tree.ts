export default {
  tree: 'Tree',

  basic: 'Basic',
  editTree: 'Right-click',
  actionTree: 'Function operation',
};
