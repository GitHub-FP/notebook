export default {
  settingRedo: 'Refresh',
  settingDens: 'Density',
  settingDensDefault: 'Default',
  settingDensMiddle: 'Middle',
  settingDensSmall: 'Compact',
  settingColumn: 'Column settings',
  settingColumnShow: 'Column display',
  settingReset: 'Reset',
  settingFullScreen: 'Full Screen',

  index: 'Index',

  total: 'total of {total}',
};
