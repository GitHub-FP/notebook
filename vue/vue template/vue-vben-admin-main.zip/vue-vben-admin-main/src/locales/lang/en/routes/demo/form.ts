export default {
  form: 'Form',
  basic: 'Basic',
  useForm: 'useForm',
  refForm: 'RefForm',
  advancedForm: 'Shrinkable',
  ruleForm: 'Form validation',
  dynamicForm: 'Dynamic',
  customerForm: 'Custom',
};
