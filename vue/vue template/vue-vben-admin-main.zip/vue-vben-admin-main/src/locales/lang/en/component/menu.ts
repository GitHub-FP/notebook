export default {
  search: 'Menu search',
};
