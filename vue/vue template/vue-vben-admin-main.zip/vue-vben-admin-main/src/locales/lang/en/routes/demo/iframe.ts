export default {
  frame: 'External',
  antv: 'antVue doc (embedded)',
  doc: 'Project doc (embedded)',
  docExternal: 'Project doc (external)',
};
