export default {
  dashboard: 'Dashboard',
  welcome: 'Home',
  workbench: 'Workbench',
  analysis: 'Analysis',
};
