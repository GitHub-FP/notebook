export default {
  level: 'Multi menu cache',
};
