export default {
  error: 'verification failed！',
  time: 'The verification is successful and it takes {time} seconds！',

  redoTip: 'Click the picture to refresh',

  dragText: 'Hold down the slider and drag',
  successText: 'Verified',
};
