export default {
  cancelText: 'Close',
  okText: 'Confirm',
};
