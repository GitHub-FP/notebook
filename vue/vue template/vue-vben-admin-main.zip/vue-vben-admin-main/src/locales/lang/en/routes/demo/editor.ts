export default {
  editor: 'Editor',
  markdown: 'Markdown editor',

  tinymce: 'Rich text',
  tinymceBasic: 'Basic',
  tinymceForm: 'embedded form',
};
