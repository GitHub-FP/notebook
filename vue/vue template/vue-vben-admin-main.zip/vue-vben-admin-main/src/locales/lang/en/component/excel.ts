export default {
  exportModalTitle: 'Export data',
  fileType: 'File type',
  fileName: 'File name',
};
