export default {
  permission: 'Permission',

  front: 'front-end',
  frontPage: 'Page',
  frontBtn: 'Button',
  frontTestA: 'Test page A',
  frontTestB: 'Test page B',

  back: 'background',
  backPage: 'Page',
  backBtn: 'Button',
};
