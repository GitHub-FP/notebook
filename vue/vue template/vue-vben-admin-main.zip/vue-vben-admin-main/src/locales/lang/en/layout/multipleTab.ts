export default {
  redo: 'Refresh',
  close: 'Close',
  closeLeft: 'Close Left',
  closeRight: 'Close Right',
  closeOther: 'Close Other',
  closeAll: 'Close All',
  putAway: 'PutAway',
  unfold: 'Unfold',
};
