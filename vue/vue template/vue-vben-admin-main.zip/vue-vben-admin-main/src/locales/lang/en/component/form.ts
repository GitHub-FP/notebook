export default {
  resetButton: 'Reset',
  submitButton: 'Search',
  putAway: 'Put away',
  unfold: 'Unfold',

  input: 'Please Input ',
  choose: 'Please Choose ',

  maxTip: 'The number of characters should be less than {0}',
};
