export default {
  onlinePreview: 'Preview',
  onlineDocument: 'Document',
};
