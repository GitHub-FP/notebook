export default {
  charts: 'Chart',
  map: 'Map',
  line: 'Line',
  pie: 'Pie',
  apexChart: 'ApexChart',
};
