export default {
  alert: '锁屏密码错误',
  backToLogin: '返回登录',
  entry: '进入系统',
  placeholder: '请输入锁屏密码或者用户密码',
};
