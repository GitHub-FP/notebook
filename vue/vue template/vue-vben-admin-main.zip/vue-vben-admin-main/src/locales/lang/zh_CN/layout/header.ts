export default {
  // user dropdown
  dropdownItemDoc: '文档',
  dropdownItemLoginOut: '退出系统',

  // tooltip
  tooltipErrorLog: '错误日志',
  tooltipLock: '锁定屏幕',
  tooltipNotify: '消息通知',
  tooltipRedo: '刷新',
  tooltipEntryFull: '全屏',
  tooltipExitFull: '退出全屏',

  // lock
  lockScreenPassword: '锁屏密码',
  lockScreen: '锁定屏幕',
  lockScreenBtn: '锁定',
  notLockScreenPassword: '不设置密码锁屏',

  home: '首页',
};
