export default {
  search: '菜单搜索',
};
