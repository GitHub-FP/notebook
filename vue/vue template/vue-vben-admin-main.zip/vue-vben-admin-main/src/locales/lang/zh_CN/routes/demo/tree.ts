export default {
  tree: 'Tree',

  basic: '基础树',
  editTree: '右键示例',
  actionTree: '函数操作示例',
};
