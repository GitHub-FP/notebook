export default {
  resetButton: '重置',
  submitButton: '查询',
  putAway: '收起',
  unfold: '展开',

  input: '请输入',
  choose: '请选择',

  maxTip: '字符数应小于{0}位',
};
