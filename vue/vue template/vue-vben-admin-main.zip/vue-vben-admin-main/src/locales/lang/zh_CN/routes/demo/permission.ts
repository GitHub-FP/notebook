export default {
  permission: '权限管理',

  front: '基于前端权限',
  frontPage: '页面权限',
  frontBtn: '按钮权限',
  frontTestA: '权限测试页A',
  frontTestB: '权限测试页B',

  back: '基于后台权限',
  backPage: '页面权限',
  backBtn: '按钮权限',
};
