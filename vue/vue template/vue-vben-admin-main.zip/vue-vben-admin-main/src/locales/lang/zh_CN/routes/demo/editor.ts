export default {
  editor: '编辑器',
  markdown: 'markdown编辑器',

  tinymce: '富文本',
  tinymceBasic: '基础使用',
  tinymceForm: '嵌入form',
};
