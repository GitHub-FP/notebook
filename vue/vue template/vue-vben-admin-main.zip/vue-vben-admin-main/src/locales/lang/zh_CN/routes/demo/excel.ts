export default {
  excel: 'Excel',
  customExport: '选择导出格式',
  jsonExport: 'JSON数据导出',
  arrayExport: 'Array数据导出',
  importExcel: '导入',
};
