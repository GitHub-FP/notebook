export default {
  exportModalTitle: '导出数据',
  fileType: '文件类型',
  fileName: '文件名',
};
