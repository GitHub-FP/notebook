export default {
  cancelText: '关闭',
  okText: '确认',
};
