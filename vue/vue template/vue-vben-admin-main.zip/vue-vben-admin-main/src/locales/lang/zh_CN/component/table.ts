export default {
  settingRedo: '刷新',
  settingDens: '密度',
  settingDensDefault: '默认',
  settingDensMiddle: '中等',
  settingDensSmall: '紧凑',
  settingColumn: '列设置',
  settingColumnShow: '列展示',
  settingReset: '重置',
  settingFullScreen: '全屏',

  index: '序号',

  total: '共 {total} 条数据',
};
