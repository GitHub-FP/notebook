export default {
  frame: '外部页面',
  antv: 'antVue文档(内嵌)',
  doc: '项目文档(内嵌)',
  docExternal: '项目文档(外链)',
};
