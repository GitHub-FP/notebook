export default {
  loadingText: '加载中...',
  cancelText: '关闭',
  okText: '确认',
};
