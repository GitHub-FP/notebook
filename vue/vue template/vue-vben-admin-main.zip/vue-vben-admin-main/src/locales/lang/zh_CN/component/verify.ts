export default {
  error: '验证失败！',
  time: '验证校验成功,耗时{time}秒！',

  redoTip: '点击图片可刷新',

  dragText: '请按住滑块拖动',
  successText: '验证通过',
};
