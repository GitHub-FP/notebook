export default {
  backLogin: '返回登录',
  backHome: '返回首页',
  redo: '刷新',
  subTitle403: '抱歉，您无权访问此页面。',
  subTitle404: '抱歉，您访问的页面不存在。',
  subTitle500: '抱歉，服务器报告错误。',
  noDataTitle: '当前页无数据',
  networkErrorTitle: '网络错误',
  networkErrorSubTitle: '抱歉，您的网络连接已断开，请检查您的网络！',
};
