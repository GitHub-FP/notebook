export default {
  level: '多级菜单缓存',
};
