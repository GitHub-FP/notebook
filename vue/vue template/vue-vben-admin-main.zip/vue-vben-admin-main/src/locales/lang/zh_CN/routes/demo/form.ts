export default {
  form: 'Form',
  basic: '基础表单',
  useForm: 'useForm',
  refForm: 'RefForm',
  advancedForm: '可收缩表单',
  ruleForm: '表单验证',
  dynamicForm: '动态表单',
  customerForm: '自定义组件',
};
