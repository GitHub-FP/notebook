export default {
  dashboard: 'Dashboard',
  welcome: '首页',
  workbench: '工作台',
  analysis: '分析页',
};
