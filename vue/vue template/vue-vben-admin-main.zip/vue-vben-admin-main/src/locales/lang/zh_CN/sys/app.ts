export default {
  loginOutTip: '温馨提醒',
  loginOutMessage: '是否确认退出系统?',
  menuLoading: '菜单加载中...',
};
