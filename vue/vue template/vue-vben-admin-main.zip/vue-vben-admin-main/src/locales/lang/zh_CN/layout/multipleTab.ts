export default {
  redo: '刷新',
  close: '关闭',
  closeLeft: '关闭左侧',
  closeRight: '关闭右侧',
  closeOther: '关闭其他',
  closeAll: '关闭全部',
  putAway: '收起',
  unfold: '展开',
};
