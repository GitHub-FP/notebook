export default {
  login: '登录',
};
