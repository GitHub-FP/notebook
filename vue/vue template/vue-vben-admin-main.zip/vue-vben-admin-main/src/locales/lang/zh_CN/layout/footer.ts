export default {
  onlinePreview: '在线预览',
  onlineDocument: '在线文档',
};
