export default {
  charts: '图表库',
  map: '地图',
  line: '折线图',
  pie: '饼图',
  apexChart: 'ApexChart',
};
