const getters = {
  rememberPass: (state: object) => state['rememberPass'],
  isFold: (state: object) => state['isFold'],
  percentage: (state: object) => state['percentage']
}

export default getters;